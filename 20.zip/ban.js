window.addEventListener('load', function() {
	
	setInterval(function() {
		$('#bn').text(parseInt($('#bn').text(),10)-1);
		if ($('#bn').text()<0) $('#bn').text("Обновите страницу");
				

	},1000);

});