window.addEventListener('load', function() {
    document.body.addEventListener('submit', function(event) {
        if (event.target.getAttribute("class") == "fl") return 0;
        myform = event.target;
        event.preventDefault();
        var xhr = new XMLHttpRequest();
        if (xhr) {
            var elems = myform.elements, // все элементы формы
                url = myform.action, // путь к обработчику
                params = [];
            for (var i = 0; i < elems.length; i++) {
                params.push(elems[i].name + '=' + elems[i].value);
            }
            xhr.open('POST', url, true);
            xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    document.body.innerHTML = xhr.responseText;
                }
            }
            xhr.send(params.join('&'));
        }
    });

    $('.fl').submit(function(event) {

        event.preventDefault();
        let formData = new FormData(this);
        $.ajax({
                type: "POST",
                processData: false,
                contentType: false,
                url: "index.php",
                data: formData
            })
            .done(function(data) {
                $('body').html(data);

            });

    });


    setInterval(function() {

        if ($('#bn').text() < 0) $('#bn').text("Обновите страницу");
        else $('#bn').text(parseInt($('#bn').text(), 10) - 1);
    }, 1000);

});