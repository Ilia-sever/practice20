<?php
header('Content-type: text/html; charset=utf-8');
require_once 'oop.php';

$fl = fopen("config.txt", "r");

$conf = array();
$l=0;
$strs = array("directory:","host:","user:",'password:','db_name:');
while (!feof($fl))
{
    $conf[$l]=fgets($fl);
    $conf[$l] = trim(str_replace($strs, '', $conf[$l]));
    $l++;
}
$pd= new Database ($conf[1],$conf[4],$conf[2],$conf[3]);





function setfl($conf,$ava,$tmp)
{
    @mkdir($conf[0],0777);
    $ava = $_FILES['avatar'];
    $tmp = $ava['tmp_name'];
    $info=getimagesize($tmp);
    if (preg_match('{image/(.*)}is',$info['mime'])) {
        $info = pathinfo($ava['name']);
        $filename = basename($ava['name'],'.'.$info['extension']);
        $filename= $filename . rand(0,9) . rand(0,9) . '.' . $info['extension'];
        $name = iconv(mb_detect_encoding(basename($ava['name'])),'windows-1251',"$conf[0]/" . $filename);
        move_uploaded_file($tmp, $name);
        $name=iconv('windows-1251', 'utf-8', $name);
        
        return $name;
    }
    else 
    {
        echo 'Попытка вставки неизображения. Повторите загрузку';
        require_once("room.html");
        die();
    }
}


function tsk($n,$nam)
{
    if (!empty($_POST["$n"])) {
        $p = $_POST["$n"];
        
    } else {
        echo 'Пустое поле: '. $nam . '. Занесение данных невозможно';
        if ($_SESSION['id']==0) require_once("registration.html"); 
        die();

    }
    return $p;
}

function tskpt ($ar1, $ar2, $n)
{
    $ar1[0]=0;
    for ($i=1;$i<$n;$i++)
    {
        if (!preg_match($ar2[$i-1], $ar1[$i])) {
            echo "Некорректный ввод. Занесение данных невозможно";
            if ($_SESSION['id']==0) require_once("registration.html"); 
            die();
        }
    }
}



function protect()
{
    $n = func_num_args(); 
    $ms = func_get_args(); 
    $ms2=array();
    $ms2[0]=0;
    $j=1;

    for($i = 0; $i < $n; $i+=2)
    {
            

        if  ((preg_match('/(and|null|not|union|select|from|where|group|order|having|limit|into|file|case)/i', $ms[$i]) ) or (preg_match('/#=*/',$ms[$i])))
        {
            session_start();
            $_SESSION['time']=time();
            $_SESSION['time-del']=1;

            die ("Попытка SQL-атаки. Доступ закрыт на 3 минуты");
        }
        if  (preg_match('(\<(/?[^>]+)>)', $ms[$i]))
        {
            session_start();
            $_SESSION['time']=time();
            $_SESSION['time-del']=2;
            die ("Попытка HTML-атаки. Доступ закрыт на 5 минут");
        }

        if (strpos($ms[$i+1], "pas") !== false)
        {
            $ms[$i]=md5(md5($ms[$i])); 
        }
        if (strpos($ms[$i+1], 'sql') !== false)
        {
            $ms[$i]=stripslashes($ms[$i]); 
        }
        if (strpos($ms[$i+1], 'html') !== false)
        {
            $ms[$i]=htmlentities($ms[$i], ENT_IGNORE);
            $ms[$i] = htmlspecialchars($ms[$i], ENT_IGNORE);
            
        }
        $ms2[$j]=$ms[$i];
        $j++;
   } 
   return $ms2;
}


$m = array();
$m[0]=0;


if (isset($_POST['sub2'])) {
    session_start();
    if (!isset($_SESSION['id']))
    {
        $_SESSION['id']=0;
        $_SESSION['att']=3;

    }
    $m = protect (
         tsk('log','логин' ), 'sqlhtml',
        tsk('pas','пароль' ), 'sqlhtml'
        
        );
     
     $m[2]=md5(md5($m[2]));

    $resu=$pd->count("SELECT count(`log`) FROM  `user` where `log`=? and `pas`=?;",array($m[1],$m[2]));
    
    if ($resu > 0) 
    {
        $buf = $pd->select("SELECT * FROM  `user` where `log`=? and `pas`=?;",array($m[1],$m[2]));
        
        
        $_SESSION['id']=$buf[0];   
        for ($i=3;$i<10;$i++)
        {
         $m[$i]=$buf[$i];
        }
        $_SESSION['id'] = $m[1];
        $_SESSION['time'] = 1;
        $_SESSION['time-del'] = 0;   
        require_once("room.html");
    } 
    else 
    {
        $_SESSION['att']=(int)$_SESSION['att']-1;
        if ($_SESSION['att']==0)
        {
            $_SESSION['time'] = time();
            $_SESSION['time-del'] = 3;
            $bn=180;
            require_once("ban.html");
            die();

        } 
        echo "Неверный вввод логина или пароля. У вас ещё ".$_SESSION['att']." попыток до бана на 3 минуты ";
        require_once("registration.html");

    }
}
else
if ((isset($_FILES['avatar']))&&(is_uploaded_file($_FILES['avatar']['tmp_name'])))
{
    session_start();
       
    if ((!isset($_SESSION['id']))||($_SESSION['id']==0)) 
    { 
        echo "Ошибка. Введите личные данные для возможности загрузить аватар"; 
        require_once("registration.html");
        die();
    };
      
    
        $ava = $_FILES['avatar'];
        $tmp = $ava['tmp_name'];
        $m[9] = setfl($conf,$ava,$tmp); 
        
        $pd->simple_query("UPDATE `user` SET `link`=? WHERE `log`=?;",array($m[9],$_SESSION['id']));
        //require_once("room.html"); 

        $resu = $pd->count("SELECT count(`log`) FROM  `user` where `log`=?;",array($_SESSION['id']));
        
       
        if ($resu > 0) {
            $buf=$pd->select("SELECT * FROM  `user` where log=?;",array($_SESSION['id']));
            
                             
            for ($i=1;$i<10;$i++)
            {
             $m[$i]=$buf[$i];
            }
            require_once("room.html");
        }
        

        
    
}
else
if ((isset($_POST['sub1']))||(isset($_POST['sub3']))) {

    session_start();
    if (isset($_POST['sub1'])) 
    $_SESSION['id'] = 0;

     $m = protect (
         tsk('log','логин' ), 'sqlhtml',
        tsk('pas','пароль' ), 'sqlhtml',
        tsk('name','имя' ), 'html',
        tsk('surname','фамилия' ), 'html',
        tsk('patron','отчество' ), 'html',
        tsk('date','дата рождения' ), 'sqlhtml',
        tsk('email','email' ), 'sqlhtml',
        tsk('phone','телефон' ),  'sqlhtml'
        );
     tskpt($m, array(
     "/((?=^.{8,}$)(?=.*[A-Za-z])(?!.*\W)((?:.*[0-9]){2,}).*)/u" ,
     "((?=^.{7,18}$)(?=.*[A-Z])(?!.*[А-Яа-яЁё])((?:.*[!@#$%^&*\[\]\{\}]){2,}).*)",
     "/[0-9A-Za-zа-яА-ЯЁё]{2,14}/u",
     "/[A-Za-zа-яА-ЯЁё]{4,14}/u",
     "/[A-Za-zа-яА-ЯЁё]{4,14}/u",
     "/[0-9]+/u",
     "/[@]+/u",
     "/[0-9]+/u",
      ), 9);
     $m[2]=md5(md5($m[2]));

    if (isset($_POST['sub1'])) 
    {
        $resu = $pd->count("SELECT count(`log`) FROM  `user` where `log`=?;",array($m[1]));
        
        if ($resu!=0) 
        {
            echo 'Данный логин существует';
            require_once("registration.html");
            die();
        }
        $resu = $pd->count("SELECT count(`email`) FROM  `user` where `email`=?;",array($m[7]));
        
        if ($resu!=0) 
        {
            echo 'Данный email существует';
            require_once("registration.html");
            die();
        }  
   
        $pd->simple_query("INSERT INTO `user` (`log`, `pas`, `name`, `surname`, `patron`, `date`, `email`, `phone`) VALUES (?,?,?,?,?,?,?,?);",array($m[1],$m[2],$m[3],$m[4],$m[5],$m[6],$m[7],$m[8]));
        
        $_SESSION['id'] = $m[1];
        $_SESSION['time'] = 1;
        $_SESSION['time-del'] = 0;

        $buf=$pd->count("SELECT `link` FROM  `user` where log=?;",array($m[1]));
        if ($buf=="") {  echo "Загрузите аватар для окончания регистрации"; $cls='cls'; require_once("registration.html");}
        else require_once("room.html");
        echo $buf;
      
    }

    if (isset($_POST['sub3'])) {

        $m[9]=$pd->count("SELECT `link` FROM  `user` where `log`=?",array($m[1]));
        $resu=$pd->count("SELECT count(`email`) FROM  `user` where `email`=? and not `log` = ?",array($m[7],$m[1]));

        if ($resu!=0) 
        {
            echo 'Данный email существует';
            require_once("room.html");
            die();
        } 

        $pd->simple_query("UPDATE `user` SET `name`= ?, `surname`=?, `patron`=? , `date`=?,`email`=? , `phone`=?   WHERE `log`=?;",array($m[3],$m[4],$m[5],$m[6],$m[7],$m[8],$m[1]));
        
                
           require_once("room.html");
          
       }
   }
  

else
{
    session_start();
    if (isset($_SESSION['id']))
    {
        if ((time()-$_SESSION['time']<300)&&($_SESSION['time-del']==2))
        {
            die ("Попытка HTML-атаки. Доступ закрыт на 5 минут");
        }
        if ((time()-$_SESSION['time']<180)&&($_SESSION['time-del']==1))
        {
            die ("Попытка SQL-атаки. Доступ закрыт на 3 минуты");
        }
        if ((time()-$_SESSION['time']<180)&&($_SESSION['time-del']==3))
        {
            $bn=180-(time()-$_SESSION['time']);
            require_once('ban.html');
            die ();
        } 
        $_SESSION['att']=3;

        $resu = $pd->count("SELECT count(`log`) FROM  `user` where `log`=?;",array($_SESSION['id']));
        
       
        if ($resu > 0) {
            $buf=$pd->select("SELECT * FROM  `user` where log=?;",array($_SESSION['id']));
            
                             
            for ($i=1;$i<10;$i++)
            {
             $m[$i]=$buf[$i];
            }
            require_once("room.html");
        }   else
        require_once("registration.html");  
    }
    else
    {

        require_once("registration.html");
    }
}

$pd = null;



